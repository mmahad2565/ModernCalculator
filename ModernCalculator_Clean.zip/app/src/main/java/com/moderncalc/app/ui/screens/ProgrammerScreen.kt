package com.moderncalc.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.moderncalc.app.ui.components.ButtonVariant
import com.moderncalc.app.ui.components.CalcButton
import com.moderncalc.app.ui.theme.LocalAppPalette
import com.moderncalc.app.viewmodel.CalcViewModel

@Composable
fun ProgrammerScreen(vm: CalcViewModel) {
    val ui by vm.ui.collectAsStateSafe()
    val p = LocalAppPalette.current

    // Compute other-base representations of the current value.
    val decimal: Long = try { java.lang.Long.parseLong(ui.progValue, ui.progBase) } catch (_: Throwable) { 0L }
    val bases = listOf("HEX" to 16, "DEC" to 10, "OCT" to 8, "BIN" to 2)

    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(p.surface.cardBg)
                .border(1.dp, p.surface.border, RoundedCornerShape(24.dp))
                .padding(16.dp)
        ) {
            // Display + base switcher
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(p.surface.panelBg)
                    .border(1.dp, p.surface.border, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Text("PROGRAMMER · Base ${ui.progBase}",
                    color = p.surface.textMeta, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                Text(ui.progValue,
                    color = p.surface.text, fontSize = 32.sp,
                    fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
                bases.forEach { (label, base) ->
                    val active = ui.progBase == base
                    val accent = p.theme.modeProgrammer
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (active) p.tint(accent) else p.surface.cardBg)
                            .border(1.dp, if (active) p.tintBorder(accent) else p.surface.border, RoundedCornerShape(8.dp))
                            .simpleClickable { vm.progSetBase(base) }
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(label,
                            color = if (active) (if (p.isDark) androidx.compose.ui.graphics.Color(0xFFFBBF24) else androidx.compose.ui.graphics.Color(0xFF92400E)) else p.surface.textMuted,
                            fontSize = 10.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(40.dp))
                        Text(
                            when (base) {
                                16 -> decimal.toString(16).uppercase()
                                10 -> decimal.toString(10)
                                8  -> decimal.toString(8)
                                else -> decimal.toString(2)
                            },
                            color = p.surface.text, fontFamily = FontFamily.Monospace,
                            fontSize = 14.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                }
            }

            Spacer(Modifier.height(12.dp))

            // Bit ops row
            KeypadRow {
                CalcButton("AND", ButtonVariant.FN, { vm.progOp("AND") }, Modifier.weight(1f)); Sp()
                CalcButton("OR",  ButtonVariant.FN, { vm.progOp("OR") },  Modifier.weight(1f)); Sp()
                CalcButton("XOR", ButtonVariant.FN, { vm.progOp("XOR") }, Modifier.weight(1f)); Sp()
                CalcButton("NOT", ButtonVariant.FN, { vm.progNot() },     Modifier.weight(1f)); Sp()
                CalcButton("<<",  ButtonVariant.FN, { vm.progOp("LSH") }, Modifier.weight(1f)); Sp()
                CalcButton(">>",  ButtonVariant.FN, { vm.progOp("RSH") }, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))

            // A-F
            KeypadRow {
                listOf("A","B","C","D","E","F").forEachIndexed { i, d ->
                    val enabled = "0123456789ABCDEF".indexOf(d) < ui.progBase
                    CalcButton(d, ButtonVariant.FN, { vm.progAppend(d) }, Modifier.weight(1f), enabled = enabled)
                    if (i < 5) Sp()
                }
            }
            Spacer(Modifier.height(8.dp))

            // 7 8 9 / * C
            KeypadRow {
                CalcButton("7", ButtonVariant.NUM, { vm.progAppend("7") }, Modifier.weight(1f), enabled = 7 < ui.progBase); Sp()
                CalcButton("8", ButtonVariant.NUM, { vm.progAppend("8") }, Modifier.weight(1f), enabled = 8 < ui.progBase); Sp()
                CalcButton("9", ButtonVariant.NUM, { vm.progAppend("9") }, Modifier.weight(1f), enabled = 9 < ui.progBase); Sp()
                CalcButton("÷", ButtonVariant.OP,  { vm.progOp("/") },     Modifier.weight(1f)); Sp()
                CalcButton("×", ButtonVariant.OP,  { vm.progOp("*") },     Modifier.weight(1f)); Sp()
                CalcButton("C", ButtonVariant.CLEAR, { vm.progClear() },   Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))

            // 4 5 6 - + ⌫
            KeypadRow {
                CalcButton("4", ButtonVariant.NUM, { vm.progAppend("4") }, Modifier.weight(1f), enabled = 4 < ui.progBase); Sp()
                CalcButton("5", ButtonVariant.NUM, { vm.progAppend("5") }, Modifier.weight(1f), enabled = 5 < ui.progBase); Sp()
                CalcButton("6", ButtonVariant.NUM, { vm.progAppend("6") }, Modifier.weight(1f), enabled = 6 < ui.progBase); Sp()
                CalcButton("−", ButtonVariant.OP,  { vm.progOp("-") },     Modifier.weight(1f)); Sp()
                CalcButton("+", ButtonVariant.OP,  { vm.progOp("+") },     Modifier.weight(1f)); Sp()
                CalcButton(variant = ButtonVariant.OP, onClick = { vm.progBackspace() }, modifier = Modifier.weight(1f)) { c ->
                    Icon(Icons.Filled.Backspace, contentDescription = "Delete", tint = c)
                }
            }
            Spacer(Modifier.height(8.dp))

            // 1 2 3 0 =
            KeypadRow {
                CalcButton("1", ButtonVariant.NUM, { vm.progAppend("1") }, Modifier.weight(1f), enabled = 1 < ui.progBase); Sp()
                CalcButton("2", ButtonVariant.NUM, { vm.progAppend("2") }, Modifier.weight(1f), enabled = 2 < ui.progBase); Sp()
                CalcButton("3", ButtonVariant.NUM, { vm.progAppend("3") }, Modifier.weight(1f), enabled = 3 < ui.progBase); Sp()
                CalcButton("0", ButtonVariant.NUM, { vm.progAppend("0") }, Modifier.weight(2f), enabled = true); Sp()
                CalcButton("=", ButtonVariant.EQ,  { vm.progEquals() },    Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun KeypadRow(content: @Composable RowScope.() -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, content = content)
}
@Composable private fun Sp() { Spacer(Modifier.width(8.dp)) }
