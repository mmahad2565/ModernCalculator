package com.moderncalc.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings")

class SettingsRepository(private val context: Context) {

    companion object {
        private val KEY_DARK = booleanPreferencesKey("dark_mode")
        private val KEY_THEME = stringPreferencesKey("theme_key")
    }

    val darkMode: Flow<Boolean?> = context.dataStore.data.map { it[KEY_DARK] }
    val themeKey: Flow<String> = context.dataStore.data.map { it[KEY_THEME] ?: "lilac" }

    suspend fun setDarkMode(enabled: Boolean) {
        context.dataStore.edit { it[KEY_DARK] = enabled }
    }

    suspend fun setThemeKey(key: String) {
        context.dataStore.edit { it[KEY_THEME] = key }
    }
}
