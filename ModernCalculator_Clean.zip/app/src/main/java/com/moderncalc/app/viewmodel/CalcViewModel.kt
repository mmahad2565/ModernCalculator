package com.moderncalc.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.moderncalc.app.data.AppDatabase
import com.moderncalc.app.data.HistoryDao
import com.moderncalc.app.data.HistoryEntry
import com.moderncalc.app.data.SettingsRepository
import com.moderncalc.app.engine.ExpressionEvaluator
import com.moderncalc.app.engine.ExpressionEvaluator.AngleMode
import com.moderncalc.app.network.CurrencyService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class CalcMode { STANDARD, SCIENTIFIC, PROGRAMMER, UNITS, CURRENCY, HISTORY }

data class CalcUiState(
    val expr: String = "",
    val preview: String = "",
    val memory: Double = 0.0,
    val angleMode: AngleMode = AngleMode.DEG,
    val error: String = "",

    // programmer
    val progValue: String = "0",
    val progBase: Int = 10, // 2/8/10/16
    val progPendingOp: String? = null,
    val progPendingA: Long? = null,

    // units
    val unitGroup: String = "Length",
    val unitFrom: String = "Meter",
    val unitTo: String = "Kilometer",
    val unitInput: String = "1",

    // temperature
    val tempFrom: String = "Celsius",
    val tempTo: String = "Fahrenheit",
    val tempInput: String = "100",

    // currency
    val ccyFrom: String = "USD",
    val ccyTo: String = "EUR",
    val ccyInput: String = "100",
    val ccyRates: Map<String, Double> = emptyMap(),
    val ccyLoading: Boolean = false,
    val ccyError: String = "",
    val ccyFetchedAt: String = "",
)

class CalcViewModel(app: Application) : AndroidViewModel(app) {

    private val dao: HistoryDao = AppDatabase.get(app).historyDao()
    private val settings = SettingsRepository(app)

    private val _mode = MutableStateFlow(CalcMode.STANDARD)
    val mode: StateFlow<CalcMode> = _mode.asStateFlow()

    private val _ui = MutableStateFlow(CalcUiState())
    val ui: StateFlow<CalcUiState> = _ui.asStateFlow()

    val history: StateFlow<List<HistoryEntry>> = dao.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val darkMode: StateFlow<Boolean?> = settings.darkMode
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val themeKey: StateFlow<String> = settings.themeKey
        .stateIn(viewModelScope, SharingStarted.Eagerly, "lilac")

    // ---------- mode/theme ----------
    fun setMode(m: CalcMode) { _mode.value = m; if (m == CalcMode.CURRENCY && _ui.value.ccyRates.isEmpty()) fetchRates() }
    fun setDarkMode(enabled: Boolean) = viewModelScope.launch { settings.setDarkMode(enabled) }
    fun setThemeKey(k: String) = viewModelScope.launch { settings.setThemeKey(k) }

    // ---------- standard/scientific ----------
    private fun updatePreview(newExpr: String, angle: AngleMode) {
        if (newExpr.isEmpty()) { _ui.update { it.copy(expr = "", preview = "", error = "") }; return }
        val preview = try { ExpressionEvaluator.format(ExpressionEvaluator.eval(newExpr, angle)) }
                      catch (_: Throwable) { "" }
        _ui.update { it.copy(expr = newExpr, preview = preview, error = "") }
    }

    fun append(s: String) { updatePreview(_ui.value.expr + s, _ui.value.angleMode) }
    fun applyFn(fn: String) { updatePreview(_ui.value.expr + fn + "(", _ui.value.angleMode) }
    fun backspace() { updatePreview(_ui.value.expr.dropLast(1), _ui.value.angleMode) }
    fun clearAll() { _ui.update { it.copy(expr = "", preview = "", error = "") } }
    fun toggleSign() {
        val e = _ui.value.expr
        val next = if (e.startsWith("-")) e.drop(1) else "-$e"
        updatePreview(next, _ui.value.angleMode)
    }
    fun toggleAngleMode() {
        val m = if (_ui.value.angleMode == AngleMode.DEG) AngleMode.RAD else AngleMode.DEG
        _ui.update { it.copy(angleMode = m) }
        updatePreview(_ui.value.expr, m)
    }

    fun equals(scientific: Boolean = false) {
        val u = _ui.value
        if (u.expr.isBlank()) return
        try {
            val out = ExpressionEvaluator.format(ExpressionEvaluator.eval(u.expr, u.angleMode))
            saveHistory(if (scientific) "sci" else "std", u.expr, out)
            _ui.update { it.copy(expr = out, preview = "", error = "") }
        } catch (_: Throwable) {
            _ui.update { it.copy(error = "Invalid expression") }
        }
    }

    // ---------- memory ----------
    private fun currentValue(): Double {
        val u = _ui.value
        return u.preview.toDoubleOrNull() ?: u.expr.toDoubleOrNull() ?: 0.0
    }
    fun memAdd()    { _ui.update { it.copy(memory = it.memory + currentValue()) } }
    fun memSub()    { _ui.update { it.copy(memory = it.memory - currentValue()) } }
    fun memRecall() { append(ExpressionEvaluator.format(_ui.value.memory)) }
    fun memClear()  { _ui.update { it.copy(memory = 0.0) } }

    // ---------- programmer ----------
    private fun progDecimal(): Long {
        val v = _ui.value
        return try { java.lang.Long.parseLong(v.progValue, v.progBase) } catch (_: Throwable) { 0L }
    }
    fun progSetBase(base: Int) { _ui.update { it.copy(progBase = base) } }
    fun progAppend(ch: String) {
        _ui.update { it.copy(progValue = if (it.progValue == "0") ch else it.progValue + ch) }
    }
    fun progClear() { _ui.update { it.copy(progValue = "0", progPendingOp = null, progPendingA = null) } }
    fun progBackspace() {
        _ui.update {
            val n = if (it.progValue.length <= 1) "0" else it.progValue.dropLast(1)
            it.copy(progValue = n)
        }
    }

    private fun applyBitwise(op: String, a: Long, b: Long): Long = when (op) {
        "AND" -> a and b
        "OR"  -> a or b
        "XOR" -> a xor b
        "LSH" -> a shl b.toInt()
        "RSH" -> a shr b.toInt()
        "+"   -> a + b
        "-"   -> a - b
        "*"   -> a * b
        "/"   -> if (b != 0L) a / b else 0L
        else  -> b
    }

    fun progOp(op: String) {
        val u = _ui.value
        if (u.progPendingOp != null && u.progPendingA != null) {
            val r = applyBitwise(u.progPendingOp, u.progPendingA, progDecimal())
            saveHistory("prog", "${u.progPendingA} ${u.progPendingOp} ${progDecimal()}", r.toString())
            _ui.update {
                it.copy(
                    progValue = r.toString(it.progBase).uppercase(),
                    progPendingOp = op,
                    progPendingA = r,
                )
            }
        } else {
            _ui.update { it.copy(progPendingOp = op, progPendingA = progDecimal(), progValue = "0") }
        }
    }

    fun progEquals() {
        val u = _ui.value
        val op = u.progPendingOp ?: return
        val a = u.progPendingA ?: return
        val b = progDecimal()
        val r = applyBitwise(op, a, b)
        saveHistory("prog", "$a $op $b", r.toString())
        _ui.update {
            it.copy(
                progValue = r.toString(it.progBase).uppercase(),
                progPendingOp = null,
                progPendingA = null,
            )
        }
    }

    fun progNot() {
        val v = progDecimal().inv()
        saveHistory("prog", "NOT ${progDecimal()}", v.toString())
        _ui.update { it.copy(progValue = v.toString(it.progBase).uppercase()) }
    }

    // ---------- unit converter ----------
    fun setUnitGroup(g: String) {
        _ui.update { s ->
            val group = com.moderncalc.app.engine.UnitConversions.groups[g]
            if (group != null) {
                val keys = group.keys.toList()
                s.copy(unitGroup = g, unitFrom = keys.first(), unitTo = keys.getOrElse(1) { keys.first() })
            } else s.copy(unitGroup = g)
        }
    }
    fun setUnitFrom(u: String) { _ui.update { it.copy(unitFrom = u) } }
    fun setUnitTo(u: String)   { _ui.update { it.copy(unitTo = u) } }
    fun setUnitInput(s: String){ _ui.update { it.copy(unitInput = s) } }
    fun swapUnits() { _ui.update { it.copy(unitFrom = it.unitTo, unitTo = it.unitFrom) } }

    fun setTempFrom(u: String) { _ui.update { it.copy(tempFrom = u) } }
    fun setTempTo(u: String)   { _ui.update { it.copy(tempTo = u) } }
    fun setTempInput(s: String){ _ui.update { it.copy(tempInput = s) } }

    fun saveUnitToHistory(expression: String, result: String) = saveHistory("unit", expression, result)

    // ---------- currency ----------
    fun setCcyFrom(c: String) { _ui.update { it.copy(ccyFrom = c) } }
    fun setCcyTo(c: String)   { _ui.update { it.copy(ccyTo = c) } }
    fun setCcyInput(s: String){ _ui.update { it.copy(ccyInput = s) } }
    fun swapCcy() { _ui.update { it.copy(ccyFrom = it.ccyTo, ccyTo = it.ccyFrom) } }

    fun fetchRates() {
        _ui.update { it.copy(ccyLoading = true, ccyError = "") }
        viewModelScope.launch {
            try {
                val res = CurrencyService.api.latestUsd()
                _ui.update {
                    it.copy(
                        ccyLoading = false,
                        ccyRates = res.rates,
                        ccyFetchedAt = res.time_last_update_utc ?: "",
                    )
                }
            } catch (t: Throwable) {
                _ui.update { it.copy(ccyLoading = false, ccyError = "Network error") }
            }
        }
    }

    fun saveCurrencyToHistory(expression: String, result: String) = saveHistory("ccy", expression, result)

    // ---------- history ----------
    private fun saveHistory(mode: String, expression: String, result: String) {
        viewModelScope.launch {
            dao.insert(HistoryEntry(mode = mode, expression = expression, result = result, timestamp = System.currentTimeMillis()))
        }
    }
    fun clearHistory() = viewModelScope.launch { dao.clear() }

    fun useHistoryResult(result: String) {
        updatePreview(result, _ui.value.angleMode)
    }
}
