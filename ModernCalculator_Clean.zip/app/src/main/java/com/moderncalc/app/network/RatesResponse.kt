package com.moderncalc.app.network

import kotlinx.serialization.Serializable

@Serializable
data class RatesResponse(
    val result: String? = null,
    val base_code: String? = null,
    val time_last_update_utc: String? = null,
    val rates: Map<String, Double> = emptyMap(),
)
