package com.moderncalc.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.moderncalc.app.engine.ExpressionEvaluator
import com.moderncalc.app.engine.UnitConversions
import com.moderncalc.app.ui.theme.LocalAppPalette
import com.moderncalc.app.viewmodel.CalcViewModel

private val TEMP_GROUP = "Temperature"
private val TEMP_UNITS = listOf("Celsius", "Fahrenheit", "Kelvin")

@Composable
fun UnitsScreen(vm: CalcViewModel) {
    val ui by vm.ui.collectAsStateSafe()
    val p = LocalAppPalette.current

    val allGroups: List<String> = UnitConversions.groups.keys.toList() + TEMP_GROUP
    val isTemp = ui.unitGroup == TEMP_GROUP

    val unitsList: List<String> = if (isTemp) TEMP_UNITS
                                  else UnitConversions.groups[ui.unitGroup]?.keys?.toList() ?: emptyList()

    val result: String = if (isTemp) {
        val n = ui.tempInput.toDoubleOrNull()
        if (n == null) "—" else ExpressionEvaluator.format(UnitConversions.convertTemperature(n, ui.tempFrom, ui.tempTo))
    } else {
        val n = ui.unitInput.toDoubleOrNull()
        val group = UnitConversions.groups[ui.unitGroup]
        val f = group?.get(ui.unitFrom); val t = group?.get(ui.unitTo)
        if (n == null || f == null || t == null) "—" else ExpressionEvaluator.format(UnitConversions.convert(n, f, t))
    }

    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(p.surface.cardBg)
                .border(1.dp, p.surface.border, RoundedCornerShape(24.dp))
                .padding(16.dp)
        ) {
            // Group chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                allGroups.forEach { g ->
                    val active = ui.unitGroup == g
                    val accent = p.theme.modeUnits
                    Text(
                        text = g, fontSize = 12.sp, fontWeight = FontWeight.Medium,
                        color = if (active) (if (p.isDark) Color(0xFF86EFAC) else Color(0xFF166534)) else p.surface.textMuted,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(if (active) p.tint(accent) else p.surface.cardBg)
                            .border(1.dp, if (active) p.tintBorder(accent) else p.surface.border, RoundedCornerShape(50))
                            .clickable { vm.setUnitGroup(g) }
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // From/To fields
            UnitField(
                label = "FROM",
                unitOptions = unitsList,
                selected = if (isTemp) ui.tempFrom else ui.unitFrom,
                onUnitChange = { if (isTemp) vm.setTempFrom(it) else vm.setUnitFrom(it) },
                value = if (isTemp) ui.tempInput else ui.unitInput,
                onValueChange = { if (isTemp) vm.setTempInput(it) else vm.setUnitInput(it) },
                readOnly = false,
                bg = p.surface.cardBg,
            )

            Spacer(Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(50))
                        .background(p.surface.cardBg)
                        .border(1.dp, p.surface.border, RoundedCornerShape(50))
                        .clickable { if (!isTemp) vm.swapUnits() },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.SwapHoriz, contentDescription = "Swap", tint = p.accentTextOnTint)
                }
            }
            Spacer(Modifier.height(8.dp))

            UnitField(
                label = "TO",
                unitOptions = unitsList,
                selected = if (isTemp) ui.tempTo else ui.unitTo,
                onUnitChange = { if (isTemp) vm.setTempTo(it) else vm.setUnitTo(it) },
                value = result,
                onValueChange = {},
                readOnly = true,
                bg = p.surface.panelBg,
            )

            Spacer(Modifier.height(16.dp))
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(p.accent)
                    .clickable {
                        if (result != "—") {
                            val from = if (isTemp) ui.tempFrom else ui.unitFrom
                            val to = if (isTemp) ui.tempTo else ui.unitTo
                            val input = if (isTemp) ui.tempInput else ui.unitInput
                            vm.saveUnitToHistory("$input $from → $to", "$result $to")
                        }
                    }
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Save to history", color = if (p.isDark) Color(0xFF0F1115) else Color(0xFF1A1A1A),
                    fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun UnitField(
    label: String,
    unitOptions: List<String>,
    selected: String,
    onUnitChange: (String) -> Unit,
    value: String,
    onValueChange: (String) -> Unit,
    readOnly: Boolean,
    bg: Color,
) {
    val p = LocalAppPalette.current
    var open by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(bg)
            .border(1.dp, p.surface.border, RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Text(label, color = p.surface.textMeta, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))

        Box {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(50))
                    .border(1.dp, p.surface.border, RoundedCornerShape(50))
                    .clickable { open = true }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(selected, color = p.surface.text, fontSize = 13.sp, modifier = Modifier.weight(1f))
                Text("▾", color = p.surface.textMuted, fontSize = 12.sp)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                unitOptions.forEach { u ->
                    DropdownMenuItem(
                        text = { Text(u, color = p.surface.text) },
                        onClick = { onUnitChange(u); open = false },
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        if (readOnly) {
            Text(value, color = p.surface.text, fontSize = 24.sp, fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
        } else {
            TextField(
                value = value,
                onValueChange = onValueChange,
                textStyle = TextStyle(color = p.surface.text, fontSize = 24.sp, fontFamily = FontFamily.Monospace,
                                       fontWeight = FontWeight.Bold, textAlign = TextAlign.End),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = p.accent,
                ),
            )
        }
    }
}
