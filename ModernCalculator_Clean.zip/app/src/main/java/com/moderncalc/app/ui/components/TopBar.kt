package com.moderncalc.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.SquareFoot
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.moderncalc.app.ui.theme.LocalAppPalette
import com.moderncalc.app.viewmodel.CalcMode

@Composable
fun TopBar(
    mode: CalcMode,
    memory: Double,
    onModeChange: (CalcMode) -> Unit,
    themePicker: @Composable () -> Unit,
) {
    val p = LocalAppPalette.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(p.surface.cardBg)
            .border(1.dp, p.surface.border, RoundedCornerShape(0.dp))
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Logo square
            androidx.compose.foundation.layout.Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(p.surface.headerLogoBg),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Calculate, contentDescription = null, tint = p.surface.headerLogoFg, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Modern Calculator", color = p.surface.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text("Standard · Scientific · Programmer · Units · Currency",
                    color = p.surface.textMeta, fontSize = 10.sp)
            }
            if (memory != 0.0) {
                MemoryBadge(memory)
                Spacer(Modifier.width(8.dp))
            }
            themePicker()
        }

        Spacer(Modifier.height(12.dp))

        // Mode tabs
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(p.surface.mutedBg)
                .padding(4.dp)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            ModeTab(CalcMode.STANDARD,  "Standard",   Icons.Filled.Calculate,  p.theme.modeStandard,   mode, onModeChange)
            ModeTab(CalcMode.SCIENTIFIC,"Scientific", Icons.Filled.Science,     p.theme.modeScientific, mode, onModeChange)
            ModeTab(CalcMode.PROGRAMMER,"Programmer", Icons.Filled.Memory,      p.theme.modeProgrammer, mode, onModeChange)
            ModeTab(CalcMode.UNITS,     "Units",      Icons.Filled.SquareFoot,  p.theme.modeUnits,      mode, onModeChange)
            ModeTab(CalcMode.CURRENCY,  "Currency",   Icons.Filled.AttachMoney, p.theme.modeCurrency,   mode, onModeChange)
            ModeTab(CalcMode.HISTORY,   "History",    Icons.Filled.History,     p.theme.modeHistory,    mode, onModeChange)
        }
    }
}

@Composable
private fun ModeTab(
    id: CalcMode,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color,
    current: CalcMode,
    onSelect: (CalcMode) -> Unit,
) {
    val p = LocalAppPalette.current
    val active = current == id
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (active) p.surface.cardBg else Color.Transparent)
            .clickable { onSelect(id) }
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = if (active) accent else p.surface.textMuted, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(6.dp))
        Text(label,
            color = if (active) p.surface.text else p.surface.textMuted,
            fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun MemoryBadge(value: Double) {
    val p = LocalAppPalette.current
    val bg = Color(0xFFF5A623).copy(alpha = p.tintAlpha)
    val border = Color(0xFFF5A623).copy(alpha = p.borderTintAlpha)
    val color = if (p.isDark) Color(0xFFFBBF24) else Color(0xFF92400E)
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .border(1.dp, border, RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("M = ${com.moderncalc.app.engine.ExpressionEvaluator.format(value)}",
            color = color, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}
