package com.moderncalc.app.ui.theme

import androidx.compose.ui.graphics.Color

/** A palette a user can pick from the theme picker. */
data class ColorTheme(
    val key: String,
    val label: String,
    val primary: Color,
    val primaryDark: Color,
    val primaryText: Color,
    // Per-mode accents (used to color the 6 tab icons and section accents).
    val modeStandard: Color,
    val modeScientific: Color,
    val modeProgrammer: Color,
    val modeUnits: Color,
    val modeCurrency: Color,
    val modeHistory: Color,
)

object AppThemes {
    val Lilac = ColorTheme(
        key = "lilac", label = "Lilac",
        primary = Color(0xFFB8A9E8), primaryDark = Color(0xFFA89AD8), primaryText = Color(0xFF5B21B6),
        modeStandard = Color(0xFFB8A9E8), modeScientific = Color(0xFF4ECDC4),
        modeProgrammer = Color(0xFFF5A623), modeUnits = Color(0xFF4ADE80),
        modeCurrency = Color(0xFFFF6B6B), modeHistory = Color(0xFFB8A9E8),
    )

    val Ocean = ColorTheme(
        key = "ocean", label = "Ocean",
        primary = Color(0xFF4ECDC4), primaryDark = Color(0xFF3DBAB1), primaryText = Color(0xFF115E59),
        modeStandard = Color(0xFF4ECDC4), modeScientific = Color(0xFF3B82F6),
        modeProgrammer = Color(0xFF0EA5E9), modeUnits = Color(0xFF22D3EE),
        modeCurrency = Color(0xFF06B6D4), modeHistory = Color(0xFF4ECDC4),
    )

    val Sunset = ColorTheme(
        key = "sunset", label = "Sunset",
        primary = Color(0xFFFF6B6B), primaryDark = Color(0xFFEF5757), primaryText = Color(0xFFB91C1C),
        modeStandard = Color(0xFFFF6B6B), modeScientific = Color(0xFFF5A623),
        modeProgrammer = Color(0xFFFB923C), modeUnits = Color(0xFFEF4444),
        modeCurrency = Color(0xFFF97316), modeHistory = Color(0xFFFF6B6B),
    )

    val Forest = ColorTheme(
        key = "forest", label = "Forest",
        primary = Color(0xFF4ADE80), primaryDark = Color(0xFF38C36C), primaryText = Color(0xFF166534),
        modeStandard = Color(0xFF4ADE80), modeScientific = Color(0xFF10B981),
        modeProgrammer = Color(0xFF84CC16), modeUnits = Color(0xFF22C55E),
        modeCurrency = Color(0xFF059669), modeHistory = Color(0xFF4ADE80),
    )

    val Midnight = ColorTheme(
        key = "midnight", label = "Midnight",
        primary = Color(0xFF8B5CF6), primaryDark = Color(0xFF7C4DEF), primaryText = Color(0xFF4C1D95),
        modeStandard = Color(0xFF8B5CF6), modeScientific = Color(0xFF6366F1),
        modeProgrammer = Color(0xFFA855F7), modeUnits = Color(0xFFD946EF),
        modeCurrency = Color(0xFFEC4899), modeHistory = Color(0xFF8B5CF6),
    )

    val all: List<ColorTheme> = listOf(Lilac, Ocean, Sunset, Forest, Midnight)

    fun byKey(k: String): ColorTheme = all.firstOrNull { it.key == k } ?: Lilac
}

/** Semantic surface tokens for light/dark modes. */
data class SurfacePalette(
    val pageBg: Color,
    val cardBg: Color,
    val panelBg: Color,
    val hoverBg: Color,
    val mutedBg: Color,
    val border: Color,
    val borderStrong: Color,
    val text: Color,
    val textMuted: Color,
    val textMeta: Color,
    val textDim: Color,
    val headerLogoBg: Color,
    val headerLogoFg: Color,
)

val LightSurface = SurfacePalette(
    pageBg = Color(0xFFFAFAF8),
    cardBg = Color(0xFFFFFFFF),
    panelBg = Color(0xFFFAFAF8),
    hoverBg = Color(0xFFFAFAF8),
    mutedBg = Color(0xFFF0F0F0),
    border = Color(0xFFF0F0F0),
    borderStrong = Color(0xFFE0E0E0),
    text = Color(0xFF1A1A1A),
    textMuted = Color(0xFF6B6B6B),
    textMeta = Color(0xFF9B9B9B),
    textDim = Color(0xFFE0E0E0),
    headerLogoBg = Color(0xFF1A1A1A),
    headerLogoFg = Color(0xFFFFFFFF),
)

val DarkSurface = SurfacePalette(
    pageBg = Color(0xFF0F1115),
    cardBg = Color(0xFF181B21),
    panelBg = Color(0xFF12141A),
    hoverBg = Color(0xFF1F232B),
    mutedBg = Color(0xFF22262F),
    border = Color(0xFF262A33),
    borderStrong = Color(0xFF333844),
    text = Color(0xFFF5F5F5),
    textMuted = Color(0xFFA8ADB8),
    textMeta = Color(0xFF6B7280),
    textDim = Color(0xFF3A3F4A),
    headerLogoBg = Color(0xFFF5F5F5),
    headerLogoFg = Color(0xFF0F1115),
)
