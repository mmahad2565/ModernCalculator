package com.moderncalc.app.engine

/**
 * Safe expression evaluator — tokenizer + shunting-yard, no eval().
 *
 * Supports: + - * / % ^  ( )
 *           functions: sin cos tan asin acos atan sinh cosh tanh log ln sqrt cbrt abs exp
 *           postfix:  !         (factorial)
 *           unary:    -         (negation)
 *           constants: π e
 */
object ExpressionEvaluator {

    enum class AngleMode { DEG, RAD }

    private sealed class Token {
        data class Num(val value: Double) : Token()
        data class Op(val symbol: String) : Token()
        data class Fn(val name: String) : Token()
        data class Paren(val open: Boolean) : Token()
    }

    private data class OpDef(
        val prec: Int,
        val rightAssoc: Boolean,
        val unary: Boolean = false,
        val apply: (Double, Double) -> Double,
    )

    private val OPS: Map<String, OpDef> = mapOf(
        "+"  to OpDef(1, false) { a, b -> a + b },
        "-"  to OpDef(1, false) { a, b -> a - b },
        "*"  to OpDef(2, false) { a, b -> a * b },
        "/"  to OpDef(2, false) { a, b -> a / b },
        "%"  to OpDef(2, false) { a, b -> a % b },
        "^"  to OpDef(4, true)  { a, b -> Math.pow(a, b) },
        "u-" to OpDef(3, true, unary = true) { a, _ -> -a },
        "!"  to OpDef(5, false, unary = true) { a, _ -> factorial(a) },
    )

    private fun factorial(x: Double): Double {
        if (x < 0 || x != Math.floor(x)) return Double.NaN
        if (x > 170) return Double.POSITIVE_INFINITY
        var r = 1.0
        var i = 2
        val n = x.toInt()
        while (i <= n) { r *= i; i++ }
        return r
    }

    private fun applyFn(name: String, x: Double, angle: AngleMode): Double {
        val degToRad = angle == AngleMode.DEG
        return when (name) {
            "sin"  -> Math.sin(if (degToRad) Math.toRadians(x) else x)
            "cos"  -> Math.cos(if (degToRad) Math.toRadians(x) else x)
            "tan"  -> Math.tan(if (degToRad) Math.toRadians(x) else x)
            "asin" -> Math.asin(x).let { if (degToRad) Math.toDegrees(it) else it }
            "acos" -> Math.acos(x).let { if (degToRad) Math.toDegrees(it) else it }
            "atan" -> Math.atan(x).let { if (degToRad) Math.toDegrees(it) else it }
            "sinh" -> Math.sinh(x)
            "cosh" -> Math.cosh(x)
            "tanh" -> Math.tanh(x)
            "log"  -> Math.log10(x)
            "ln"   -> Math.log(x)
            "sqrt" -> Math.sqrt(x)
            "cbrt" -> Math.cbrt(x)
            "abs"  -> Math.abs(x)
            "exp"  -> Math.exp(x)
            else   -> throw IllegalArgumentException("Unknown function: $name")
        }
    }

    private fun tokenize(input: String): List<Token> {
        // Substitute constants + friendly symbols.
        val s = input
            .replace("π", "(${Math.PI})")
            .replace("×", "*").replace("÷", "/")
            .replace("−", "-").replace("√", "sqrt")

        val tokens = mutableListOf<Token>()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            when {
                c == ' ' -> i++
                c.isDigit() || c == '.' -> {
                    val start = i
                    while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
                    tokens += Token.Num(s.substring(start, i).toDouble())
                }
                c.isLetter() -> {
                    val start = i
                    while (i < s.length && s[i].isLetter()) i++
                    val name = s.substring(start, i).lowercase()
                    // 'e' constant is a special-case identifier: substitute if standalone.
                    if (name == "e") tokens += Token.Num(Math.E)
                    else tokens += Token.Fn(name)
                }
                c == '(' -> { tokens += Token.Paren(true); i++ }
                c == ')' -> { tokens += Token.Paren(false); i++ }
                "+-*/^%!".contains(c) -> { tokens += Token.Op(c.toString()); i++ }
                else -> throw IllegalArgumentException("Unexpected char '$c'")
            }
        }

        // Detect unary minus.
        val out = mutableListOf<Token>()
        for (t in tokens) {
            if (t is Token.Op && t.symbol == "-") {
                val prev = out.lastOrNull()
                if (prev == null || prev is Token.Op || (prev is Token.Paren && prev.open)) {
                    out += Token.Op("u-")
                    continue
                }
            }
            out += t
        }
        return out
    }

    private fun toRPN(tokens: List<Token>): List<Token> {
        val out = mutableListOf<Token>()
        val stack = ArrayDeque<Token>()
        for (t in tokens) {
            when (t) {
                is Token.Num -> out += t
                is Token.Fn  -> stack.addLast(t)
                is Token.Op  -> {
                    val o1 = OPS[t.symbol] ?: throw IllegalArgumentException(t.symbol)
                    while (stack.isNotEmpty()) {
                        val top = stack.last()
                        if (top is Token.Fn) { out += stack.removeLast(); continue }
                        if (top is Token.Op) {
                            val o2 = OPS[top.symbol]!!
                            if ((!o1.rightAssoc && o1.prec <= o2.prec) ||
                                ( o1.rightAssoc && o1.prec <  o2.prec)) {
                                out += stack.removeLast(); continue
                            }
                        }
                        break
                    }
                    stack.addLast(t)
                }
                is Token.Paren -> {
                    if (t.open) stack.addLast(t)
                    else {
                        while (stack.isNotEmpty() && !(stack.last() is Token.Paren && (stack.last() as Token.Paren).open)) {
                            out += stack.removeLast()
                        }
                        if (stack.isEmpty()) throw IllegalArgumentException("Mismatched )")
                        stack.removeLast() // pop '('
                        if (stack.isNotEmpty() && stack.last() is Token.Fn) out += stack.removeLast()
                    }
                }
            }
        }
        while (stack.isNotEmpty()) {
            val top = stack.removeLast()
            if (top is Token.Paren) throw IllegalArgumentException("Mismatched (")
            out += top
        }
        return out
    }

    private fun evalRPN(rpn: List<Token>, angle: AngleMode): Double {
        val st = ArrayDeque<Double>()
        for (t in rpn) {
            when (t) {
                is Token.Num -> st.addLast(t.value)
                is Token.Op  -> {
                    val def = OPS[t.symbol]!!
                    if (def.unary) {
                        val a = st.removeLast()
                        st.addLast(def.apply(a, 0.0))
                    } else {
                        val b = st.removeLast()
                        val a = st.removeLast()
                        st.addLast(def.apply(a, b))
                    }
                }
                is Token.Fn -> {
                    val a = st.removeLast()
                    st.addLast(applyFn(t.name, a, angle))
                }
                is Token.Paren -> throw IllegalStateException("Unexpected paren in RPN")
            }
        }
        if (st.size != 1) throw IllegalStateException("Bad expression")
        return st.removeLast()
    }

    fun eval(expression: String, angle: AngleMode = AngleMode.DEG): Double {
        if (expression.isBlank()) throw IllegalArgumentException("Empty")
        return evalRPN(toRPN(tokenize(expression)), angle)
    }

    fun format(value: Double): String {
        if (value.isNaN()) return "Error"
        if (value.isInfinite()) return if (value > 0) "∞" else "-∞"
        if (value == Math.floor(value) && Math.abs(value) < 1e15) return value.toLong().toString()
        val abs = Math.abs(value)
        if (abs != 0.0 && (abs < 1e-6 || abs >= 1e15)) return "%.6e".format(value)
        // Trim trailing zeros
        val s = "%.12g".format(value)
        return s.toDouble().toString().let {
            if (it.endsWith(".0")) it.dropLast(2) else it
        }
    }
}
