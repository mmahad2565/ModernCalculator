package com.moderncalc.app.engine

/** Unit conversion tables + helpers. Base units below correspond to factor = 1. */
object UnitConversions {

    val length: Map<String, Double> = linkedMapOf(
        "Meter" to 1.0, "Kilometer" to 1000.0, "Centimeter" to 0.01, "Millimeter" to 0.001,
        "Mile" to 1609.344, "Yard" to 0.9144, "Foot" to 0.3048, "Inch" to 0.0254,
        "Nautical Mile" to 1852.0,
    )
    val weight: Map<String, Double> = linkedMapOf(
        "Kilogram" to 1.0, "Gram" to 0.001, "Milligram" to 0.000001, "Ton" to 1000.0,
        "Pound" to 0.45359237, "Ounce" to 0.028349523125, "Stone" to 6.35029318,
    )
    val volume: Map<String, Double> = linkedMapOf(
        "Liter" to 1.0, "Milliliter" to 0.001, "Cubic Meter" to 1000.0,
        "Gallon" to 3.785411784, "Quart" to 0.946352946, "Pint" to 0.473176473,
        "Cup" to 0.2365882365, "Fluid Ounce" to 0.0295735296,
    )
    val area: Map<String, Double> = linkedMapOf(
        "Square Meter" to 1.0, "Square Kilometer" to 1e6, "Square Foot" to 0.09290304,
        "Square Yard" to 0.83612736, "Acre" to 4046.8564224, "Hectare" to 10000.0,
        "Square Mile" to 2589988.110336,
    )
    val speed: Map<String, Double> = linkedMapOf(
        "Meter/second" to 1.0, "Kilometer/hour" to 1.0 / 3.6, "Mile/hour" to 0.44704,
        "Knot" to 0.514444, "Foot/second" to 0.3048,
    )
    val time: Map<String, Double> = linkedMapOf(
        "Second" to 1.0, "Millisecond" to 0.001, "Minute" to 60.0, "Hour" to 3600.0,
        "Day" to 86400.0, "Week" to 604800.0, "Year" to 31557600.0,
    )

    val groups: Map<String, Map<String, Double>> = linkedMapOf(
        "Length" to length, "Weight" to weight, "Volume" to volume,
        "Area" to area, "Speed" to speed, "Time" to time,
    )

    /** Convert a linear (proportional) unit. */
    fun convert(value: Double, from: Double, to: Double): Double = value * from / to

    /** Temperature is affine — needs its own converter. */
    fun convertTemperature(value: Double, from: String, to: String): Double {
        val k = when (from) {
            "Celsius"    -> value + 273.15
            "Fahrenheit" -> (value - 32.0) * 5.0 / 9.0 + 273.15
            else         -> value // Kelvin
        }
        return when (to) {
            "Celsius"    -> k - 273.15
            "Fahrenheit" -> (k - 273.15) * 9.0 / 5.0 + 32.0
            else         -> k
        }
    }
}
