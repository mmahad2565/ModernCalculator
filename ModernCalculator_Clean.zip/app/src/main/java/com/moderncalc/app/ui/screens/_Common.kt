package com.moderncalc.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import kotlinx.coroutines.flow.StateFlow

/** Shared helpers used by all screens. */

@Composable
fun <T> StateFlow<T>.collectAsStateSafe(): State<T> =
    this.collectAsState(initial = this.value)

fun Modifier.simpleClickable(onClick: () -> Unit): Modifier =
    this.then(Modifier.clickable(onClick = onClick))
