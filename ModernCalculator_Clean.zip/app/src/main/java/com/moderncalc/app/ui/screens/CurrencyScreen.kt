package com.moderncalc.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.moderncalc.app.engine.ExpressionEvaluator
import com.moderncalc.app.ui.theme.LocalAppPalette
import com.moderncalc.app.viewmodel.CalcViewModel

@Composable
fun CurrencyScreen(vm: CalcViewModel) {
    val ui by vm.ui.collectAsStateSafe()
    val p = LocalAppPalette.current

    val ccyList = remember(ui.ccyRates) { ui.ccyRates.keys.sorted() }

    val result: String = run {
        val n = ui.ccyInput.toDoubleOrNull()
        val rFrom = ui.ccyRates[ui.ccyFrom]; val rTo = ui.ccyRates[ui.ccyTo]
        if (n == null || rFrom == null || rTo == null) "—"
        else ExpressionEvaluator.format((n / rFrom) * rTo)
    }

    Column(
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(p.surface.cardBg)
                .border(1.dp, p.surface.border, RoundedCornerShape(24.dp))
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Currency converter",
                        color = p.surface.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        when {
                            ui.ccyLoading -> "Loading rates…"
                            ui.ccyFetchedAt.isNotEmpty() -> "Updated ${ui.ccyFetchedAt}"
                            else -> "Live rates from open.er-api.com"
                        },
                        color = p.surface.textMeta, fontSize = 10.sp,
                    )
                }
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .border(1.dp, p.surface.border, RoundedCornerShape(50))
                        .background(p.surface.cardBg)
                        .clickable { vm.fetchRates() }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (ui.ccyLoading) {
                        CircularProgressIndicator(strokeWidth = 2.dp, color = p.accent, modifier = Modifier.size(14.dp))
                    } else {
                        Icon(Icons.Filled.Refresh, contentDescription = "Refresh", tint = p.surface.text, modifier = Modifier.size(14.dp))
                    }
                    Spacer(Modifier.size(6.dp))
                    Text("Refresh", color = p.surface.text, fontSize = 12.sp)
                }
            }

            if (ui.ccyError.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                Text(ui.ccyError, color = Color(0xFFEF4444), fontSize = 12.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFFF6B6B).copy(alpha = p.tintAlpha))
                        .border(1.dp, Color(0xFFFF6B6B).copy(alpha = p.borderTintAlpha), RoundedCornerShape(12.dp))
                        .padding(12.dp))
            }

            Spacer(Modifier.height(16.dp))

            CcyField(
                label = "FROM",
                options = ccyList.ifEmpty { listOf("USD") },
                selected = ui.ccyFrom,
                onSelect = { vm.setCcyFrom(it) },
                value = ui.ccyInput,
                onValueChange = { vm.setCcyInput(it) },
                readOnly = false,
                bg = p.surface.cardBg,
            )
            Spacer(Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(50))
                        .background(p.surface.cardBg)
                        .border(1.dp, p.surface.border, RoundedCornerShape(50))
                        .clickable { vm.swapCcy() },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.SwapHoriz, contentDescription = "Swap", tint = p.theme.modeCurrency) }
            }
            Spacer(Modifier.height(8.dp))
            CcyField(
                label = "TO",
                options = ccyList.ifEmpty { listOf("EUR") },
                selected = ui.ccyTo,
                onSelect = { vm.setCcyTo(it) },
                value = result,
                onValueChange = {},
                readOnly = true,
                bg = p.surface.panelBg,
            )

            // Quick reference tiles
            if (ui.ccyRates.isNotEmpty()) {
                Spacer(Modifier.height(16.dp))
                val quick = listOf("EUR", "GBP", "JPY", "INR", "CAD", "AUD", "CNY", "PKR").filter { ui.ccyRates.containsKey(it) }
                Column {
                    quick.chunked(2).forEach { row ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { c ->
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(12.dp))
                                        .border(1.dp, p.surface.border, RoundedCornerShape(12.dp))
                                        .padding(12.dp)
                                ) {
                                    Text("1 USD =", color = p.surface.textMeta, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                    Text("${ExpressionEvaluator.format(ui.ccyRates[c] ?: 0.0)} $c",
                                        color = p.surface.text, fontSize = 13.sp, fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold)
                                }
                            }
                            // pad last row if odd count
                            if (row.size == 1) Box(modifier = Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(p.accent)
                    .clickable {
                        if (result != "—") vm.saveCurrencyToHistory("${ui.ccyInput} ${ui.ccyFrom} → ${ui.ccyTo}", "$result ${ui.ccyTo}")
                    }
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Save to history", color = if (p.isDark) Color(0xFF0F1115) else Color(0xFF1A1A1A),
                    fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun CcyField(
    label: String,
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit,
    value: String,
    onValueChange: (String) -> Unit,
    readOnly: Boolean,
    bg: Color,
) {
    val p = LocalAppPalette.current
    var open by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(bg)
            .border(1.dp, p.surface.border, RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Text(label, color = p.surface.textMeta, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Box {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(50))
                    .border(1.dp, p.surface.border, RoundedCornerShape(50))
                    .clickable { open = true }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(selected, color = p.surface.text, fontSize = 13.sp, modifier = Modifier.weight(1f))
                Text("▾", color = p.surface.textMuted, fontSize = 12.sp)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false },
                modifier = Modifier.height(300.dp)) {
                options.forEach { c ->
                    DropdownMenuItem(text = { Text(c, color = p.surface.text) },
                        onClick = { onSelect(c); open = false })
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        if (readOnly) {
            Text(value, color = p.surface.text, fontSize = 24.sp, fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
        } else {
            TextField(
                value = value, onValueChange = onValueChange,
                textStyle = TextStyle(color = p.surface.text, fontSize = 24.sp, fontFamily = FontFamily.Monospace,
                                       fontWeight = FontWeight.Bold, textAlign = TextAlign.End),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true, modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = p.accent,
                ),
            )
        }
    }
}
