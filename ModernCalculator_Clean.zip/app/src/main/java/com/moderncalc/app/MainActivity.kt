package com.moderncalc.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.moderncalc.app.ui.components.ThemePickerButtons
import com.moderncalc.app.ui.components.TopBar
import com.moderncalc.app.ui.screens.CurrencyScreen
import com.moderncalc.app.ui.screens.HistoryScreen
import com.moderncalc.app.ui.screens.ProgrammerScreen
import com.moderncalc.app.ui.screens.StandardScreen
import com.moderncalc.app.ui.screens.UnitsScreen
import com.moderncalc.app.ui.screens.collectAsStateSafe
import com.moderncalc.app.ui.theme.AppThemes
import com.moderncalc.app.ui.theme.ModernCalculatorTheme
import com.moderncalc.app.viewmodel.CalcMode
import com.moderncalc.app.viewmodel.CalcViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val vm: CalcViewModel = viewModel()
            val darkPref by vm.darkMode.collectAsStateSafe()
            val themeKey by vm.themeKey.collectAsStateSafe()
            val mode by vm.mode.collectAsStateSafe()
            val ui by vm.ui.collectAsStateSafe()

            // If the user hasn't chosen, follow system default. Otherwise honor their pick.
            val useDark = darkPref ?: androidx.compose.foundation.isSystemInDarkTheme()
            val theme = AppThemes.byKey(themeKey)

            ModernCalculatorTheme(darkTheme = useDark, theme = theme) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Box(modifier = Modifier.fillMaxSize().systemBarsPadding()) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            TopBar(
                                mode = mode,
                                memory = ui.memory,
                                onModeChange = vm::setMode,
                                themePicker = {
                                    ThemePickerButtons(
                                        isDark = useDark,
                                        currentThemeKey = themeKey,
                                        onDarkToggle = vm::setDarkMode,
                                        onThemeSelect = vm::setThemeKey,
                                    )
                                },
                            )
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(androidx.compose.ui.graphics.Color.Transparent)
                                    .verticalScroll(rememberScrollState()),
                            ) {
                                when (mode) {
                                    CalcMode.STANDARD   -> StandardScreen(vm, scientific = false)
                                    CalcMode.SCIENTIFIC -> StandardScreen(vm, scientific = true)
                                    CalcMode.PROGRAMMER -> ProgrammerScreen(vm)
                                    CalcMode.UNITS      -> UnitsScreen(vm)
                                    CalcMode.CURRENCY   -> CurrencyScreen(vm)
                                    CalcMode.HISTORY    -> HistoryScreen(vm)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
