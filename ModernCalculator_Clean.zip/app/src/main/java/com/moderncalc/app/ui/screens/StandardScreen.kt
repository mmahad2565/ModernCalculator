package com.moderncalc.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.moderncalc.app.ui.components.ButtonVariant
import com.moderncalc.app.ui.components.CalcButton
import com.moderncalc.app.ui.theme.LocalAppPalette
import com.moderncalc.app.viewmodel.CalcViewModel

@Composable
fun StandardScreen(vm: CalcViewModel, scientific: Boolean) {
    val ui by vm.ui.collectAsStateSafe()
    val p = LocalAppPalette.current

    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(p.surface.cardBg)
                .border(1.dp, p.surface.border, RoundedCornerShape(24.dp))
                .padding(16.dp)
        ) {
            // Display panel
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(p.surface.panelBg)
                    .border(1.dp, p.surface.border, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (scientific) "SCIENTIFIC" else "STANDARD",
                        color = p.surface.textMeta, fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)
                    )
                    if (scientific) {
                        Text(
                            ui.angleMode.name,
                            color = p.accentTextOnTint,
                            fontSize = 10.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(p.tint(p.theme.modeScientific))
                                .border(1.dp, p.tintBorder(p.theme.modeScientific), RoundedCornerShape(50))
                                .simpleClickable { vm.toggleAngleMode() }
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    text = if (ui.expr.isEmpty()) "0" else ui.expr,
                    color = if (ui.expr.isEmpty()) p.surface.textDim else p.surface.textMuted,
                    fontSize = 14.sp, fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = ui.preview.ifEmpty { if (ui.expr.isEmpty()) "0" else "" },
                    color = p.surface.text, fontSize = 32.sp, fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth()
                )
                if (ui.error.isNotBlank()) {
                    Text(
                        ui.error, color = Color(0xFFEF4444),
                        fontSize = 11.sp, textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            // Memory row
            KeypadRow {
                CalcButton("MC", ButtonVariant.MEM, { vm.memClear() },  Modifier.weight(1f))
                Sp()
                CalcButton("MR", ButtonVariant.MEM, { vm.memRecall() }, Modifier.weight(1f))
                Sp()
                CalcButton("M+", ButtonVariant.MEM, { vm.memAdd() },    Modifier.weight(1f))
                Sp()
                CalcButton("M−", ButtonVariant.MEM, { vm.memSub() },    Modifier.weight(1f))
                Sp()
                CalcButton("AC", ButtonVariant.CLEAR, { vm.clearAll() }, Modifier.weight(1f))
            }

            if (scientific) {
                Spacer(Modifier.height(8.dp))
                KeypadRow {
                    CalcButton("sin",   ButtonVariant.FN, { vm.applyFn("sin") },   Modifier.weight(1f)); Sp()
                    CalcButton("cos",   ButtonVariant.FN, { vm.applyFn("cos") },   Modifier.weight(1f)); Sp()
                    CalcButton("tan",   ButtonVariant.FN, { vm.applyFn("tan") },   Modifier.weight(1f)); Sp()
                    CalcButton("log",   ButtonVariant.FN, { vm.applyFn("log") },   Modifier.weight(1f)); Sp()
                    CalcButton("ln",    ButtonVariant.FN, { vm.applyFn("ln") },    Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                KeypadRow {
                    CalcButton("sin⁻¹", ButtonVariant.FN, { vm.applyFn("asin") }, Modifier.weight(1f)); Sp()
                    CalcButton("cos⁻¹", ButtonVariant.FN, { vm.applyFn("acos") }, Modifier.weight(1f)); Sp()
                    CalcButton("tan⁻¹", ButtonVariant.FN, { vm.applyFn("atan") }, Modifier.weight(1f)); Sp()
                    CalcButton("x²",    ButtonVariant.FN, { vm.append("^2") },    Modifier.weight(1f)); Sp()
                    CalcButton("xʸ",    ButtonVariant.FN, { vm.append("^") },     Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                KeypadRow {
                    CalcButton("√",  ButtonVariant.FN, { vm.applyFn("sqrt") }, Modifier.weight(1f)); Sp()
                    CalcButton("∛",  ButtonVariant.FN, { vm.applyFn("cbrt") }, Modifier.weight(1f)); Sp()
                    CalcButton("eˣ", ButtonVariant.FN, { vm.applyFn("exp") },  Modifier.weight(1f)); Sp()
                    CalcButton("π",  ButtonVariant.FN, { vm.append("π") },     Modifier.weight(1f)); Sp()
                    CalcButton("e",  ButtonVariant.FN, { vm.append("e") },     Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                KeypadRow {
                    CalcButton("(",    ButtonVariant.FN, { vm.append("(") },      Modifier.weight(1f)); Sp()
                    CalcButton(")",    ButtonVariant.FN, { vm.append(")") },      Modifier.weight(1f)); Sp()
                    CalcButton("n!",   ButtonVariant.FN, { vm.append("!") },      Modifier.weight(1f)); Sp()
                    CalcButton("|x|",  ButtonVariant.FN, { vm.applyFn("abs") },   Modifier.weight(1f)); Sp()
                    CalcButton("sinh", ButtonVariant.FN, { vm.applyFn("sinh") },  Modifier.weight(1f))
                }
            }

            Spacer(Modifier.height(8.dp))

            // Main keypad
            KeypadRow {
                CalcButton(variant = ButtonVariant.OP, onClick = { vm.backspace() }, modifier = Modifier.weight(1f)) { c ->
                    Icon(Icons.Filled.Backspace, contentDescription = "Delete", tint = c)
                }; Sp()
                CalcButton("(", ButtonVariant.OP, { vm.append("(") }, Modifier.weight(1f)); Sp()
                CalcButton(")", ButtonVariant.OP, { vm.append(")") }, Modifier.weight(1f)); Sp()
                CalcButton("÷", ButtonVariant.OP, { vm.append("/") }, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            KeypadRow {
                CalcButton("7", ButtonVariant.NUM, { vm.append("7") }, Modifier.weight(1f)); Sp()
                CalcButton("8", ButtonVariant.NUM, { vm.append("8") }, Modifier.weight(1f)); Sp()
                CalcButton("9", ButtonVariant.NUM, { vm.append("9") }, Modifier.weight(1f)); Sp()
                CalcButton("×", ButtonVariant.OP,  { vm.append("*") }, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            KeypadRow {
                CalcButton("4", ButtonVariant.NUM, { vm.append("4") }, Modifier.weight(1f)); Sp()
                CalcButton("5", ButtonVariant.NUM, { vm.append("5") }, Modifier.weight(1f)); Sp()
                CalcButton("6", ButtonVariant.NUM, { vm.append("6") }, Modifier.weight(1f)); Sp()
                CalcButton("−", ButtonVariant.OP,  { vm.append("-") }, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            KeypadRow {
                CalcButton("1", ButtonVariant.NUM, { vm.append("1") }, Modifier.weight(1f)); Sp()
                CalcButton("2", ButtonVariant.NUM, { vm.append("2") }, Modifier.weight(1f)); Sp()
                CalcButton("3", ButtonVariant.NUM, { vm.append("3") }, Modifier.weight(1f)); Sp()
                CalcButton("+", ButtonVariant.OP,  { vm.append("+") }, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            KeypadRow {
                CalcButton("±", ButtonVariant.OP,  { vm.toggleSign() }, Modifier.weight(1f)); Sp()
                CalcButton("0", ButtonVariant.NUM, { vm.append("0") },  Modifier.weight(1f)); Sp()
                CalcButton(".", ButtonVariant.NUM, { vm.append(".") },  Modifier.weight(1f)); Sp()
                CalcButton(variant = ButtonVariant.OP, onClick = { vm.append("%") }, modifier = Modifier.weight(1f)) { c ->
                    Icon(Icons.Filled.Percent, contentDescription = "Percent", tint = c)
                }
            }
            Spacer(Modifier.height(8.dp))
            CalcButton("=  Equals", ButtonVariant.EQ, { vm.equals(scientific) }, Modifier.fillMaxWidth())

            Spacer(Modifier.height(12.dp))
            Text(
                "Result auto-saves to history.", color = p.surface.textMeta,
                fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun KeypadRow(content: @Composable RowScope.() -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, content = content)
}

@Composable
private fun Sp() {
    Spacer(Modifier.width(8.dp))
}
