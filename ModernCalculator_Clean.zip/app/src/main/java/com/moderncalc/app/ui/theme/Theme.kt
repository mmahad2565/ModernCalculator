package com.moderncalc.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** Everything the UI needs from the current theme, ready to consume. */
data class AppPalette(
    val theme: ColorTheme,
    val surface: SurfacePalette,
    val isDark: Boolean,
) {
    val accent: Color get() = theme.primary
    val accentDark: Color get() = theme.primaryDark
    val accentTextOnTint: Color get() = if (isDark) Color.White else theme.primaryText

    /** Alpha for a tinted 10-15% fill; slightly stronger in dark mode. */
    val tintAlpha: Float get() = if (isDark) 0.16f else 0.10f
    val borderTintAlpha: Float get() = if (isDark) 0.33f else 0.20f

    fun tint(c: Color): Color = c.copy(alpha = tintAlpha)
    fun tintBorder(c: Color): Color = c.copy(alpha = borderTintAlpha)
}

val LocalAppPalette = staticCompositionLocalOf<AppPalette> {
    error("AppPalette not provided")
}

@Composable
fun ModernCalculatorTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    theme: ColorTheme = AppThemes.Lilac,
    content: @Composable () -> Unit,
) {
    val surface = if (darkTheme) DarkSurface else LightSurface
    val palette = AppPalette(theme = theme, surface = surface, isDark = darkTheme)

    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = theme.primary,
            onPrimary = Color(0xFF0F1115),
            background = surface.pageBg,
            surface = surface.cardBg,
            onSurface = surface.text,
        )
    } else {
        lightColorScheme(
            primary = theme.primary,
            onPrimary = Color(0xFF1A1A1A),
            background = surface.pageBg,
            surface = surface.cardBg,
            onSurface = surface.text,
        )
    }

    CompositionLocalProvider(LocalAppPalette provides palette) {
        MaterialTheme(colorScheme = colorScheme, content = content)
    }
}
