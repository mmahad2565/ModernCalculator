package com.moderncalc.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.moderncalc.app.ui.theme.LocalAppPalette

enum class ButtonVariant { NUM, OP, FN, CLEAR, EQ, MEM }

/**
 * Themed calculator button. Uses semantic variants so all keypads share style.
 * `content` receives a `Color` — pass the text/icon color to its children.
 */
@Composable
fun CalcButton(
    label: String? = null,
    variant: ButtonVariant = ButtonVariant.NUM,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    content: (@Composable (Color) -> Unit)? = null,
) {
    val p = LocalAppPalette.current
    val (bg, color, border) = when (variant) {
        ButtonVariant.NUM   -> Triple(p.surface.cardBg, p.surface.text, p.surface.border)
        ButtonVariant.OP    -> Triple(p.surface.mutedBg, p.accentTextOnTint, p.surface.border)
        ButtonVariant.FN    -> Triple(p.surface.cardBg, p.accentTextOnTint, p.surface.border)
        ButtonVariant.CLEAR -> Triple(
            Color(0xFFFF6B6B).copy(alpha = p.tintAlpha),
            if (p.isDark) Color(0xFFFCA5A5) else Color(0xFFDC2626),
            Color(0xFFFF6B6B).copy(alpha = p.borderTintAlpha),
        )
        ButtonVariant.EQ    -> Triple(p.accent, if (p.isDark) Color(0xFF0F1115) else Color(0xFF1A1A1A), p.accent)
        ButtonVariant.MEM   -> Triple(
            p.surface.cardBg,
            if (p.isDark) Color(0xFFFBBF24) else Color(0xFF92400E),
            p.surface.border,
        )
    }

    Box(
        modifier = modifier
            .height(56.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (enabled) bg else bg.copy(alpha = 0.35f))
            .border(1.dp, border, RoundedCornerShape(16.dp))
            .then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center,
    ) {
        if (content != null) {
            content(if (enabled) color else color.copy(alpha = 0.35f))
        } else if (label != null) {
            Text(
                label,
                color = if (enabled) color else color.copy(alpha = 0.35f),
                fontSize = 18.sp,
                fontWeight = if (variant == ButtonVariant.EQ) FontWeight.SemiBold else FontWeight.Medium,
            )
        }
    }
}
