package com.moderncalc.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import com.moderncalc.app.ui.theme.AppThemes
import com.moderncalc.app.ui.theme.LocalAppPalette
import androidx.compose.foundation.clickable

@Composable
fun ThemePickerButtons(
    isDark: Boolean,
    currentThemeKey: String,
    onDarkToggle: (Boolean) -> Unit,
    onThemeSelect: (String) -> Unit,
) {
    val p = LocalAppPalette.current
    var open by remember { mutableStateOf(false) }

    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {

        // Palette button + popup
        Box {
            IconButton(
                onClick = { open = !open },
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(50))
                    .background(p.surface.cardBg)
                    .border(1.dp, p.surface.border, RoundedCornerShape(50))
            ) {
                Icon(Icons.Filled.Palette, contentDescription = "Choose theme", tint = p.accent, modifier = Modifier.size(16.dp))
            }
            if (open) {
                Popup(
                    onDismissRequest = { open = false },
                    properties = PopupProperties(focusable = true),
                    offset = androidx.compose.ui.unit.IntOffset(0, 100),
                ) {
                    Box(
                        modifier = Modifier
                            .width(240.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(p.surface.cardBg)
                            .border(1.dp, p.surface.border, RoundedCornerShape(16.dp))
                            .padding(12.dp)
                    ) {
                        androidx.compose.foundation.layout.Column {
                            Text("THEME", color = p.surface.textMeta, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                AppThemes.all.forEach { th ->
                                    val selected = th.key == currentThemeKey
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(th.primary)
                                            .border(
                                                width = if (selected) 2.dp else 1.dp,
                                                color = if (selected) p.surface.text else p.surface.border,
                                                shape = RoundedCornerShape(12.dp)
                                            )
                                            .clickable { onThemeSelect(th.key) },
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        if (selected) {
                                            Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                        }
                                    }
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            Text(AppThemes.byKey(currentThemeKey).label, color = p.surface.text, fontSize = 12.sp)
                            Spacer(Modifier.height(12.dp))
                            androidx.compose.material3.Divider(color = p.surface.border)
                            Spacer(Modifier.height(12.dp))
                            Text("APPEARANCE", color = p.surface.textMeta, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                AppearanceButton("Light", Icons.Filled.LightMode, selected = !isDark, onClick = { onDarkToggle(false) }, modifier = Modifier.weight(1f))
                                AppearanceButton("Dark", Icons.Filled.DarkMode, selected = isDark, onClick = { onDarkToggle(true) }, modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }

        // Quick dark toggle
        IconButton(
            onClick = { onDarkToggle(!isDark) },
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(50))
                .background(p.surface.cardBg)
                .border(1.dp, p.surface.border, RoundedCornerShape(50))
        ) {
            if (isDark) Icon(Icons.Filled.LightMode, contentDescription = "Light mode", tint = Color(0xFFF5A623), modifier = Modifier.size(16.dp))
            else        Icon(Icons.Filled.DarkMode,  contentDescription = "Dark mode",  tint = p.accent,          modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
private fun AppearanceButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = LocalAppPalette.current
    val bg = if (selected) p.tint(p.accent) else p.surface.cardBg
    val border = if (selected) p.tintBorder(p.accent) else p.surface.border
    val color = if (selected) p.accentTextOnTint else p.surface.textMuted
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .border(1.dp, border, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(PaddingValues(vertical = 8.dp)),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(12.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = color, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}
