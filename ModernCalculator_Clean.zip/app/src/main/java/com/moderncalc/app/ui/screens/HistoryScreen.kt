package com.moderncalc.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.moderncalc.app.data.HistoryEntry
import com.moderncalc.app.ui.theme.LocalAppPalette
import com.moderncalc.app.viewmodel.CalcViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(vm: CalcViewModel) {
    val p = LocalAppPalette.current
    val history by vm.history.collectAsStateSafe()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(p.surface.cardBg)
                .border(1.dp, p.surface.border, RoundedCornerShape(24.dp))
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.History, contentDescription = null, tint = p.accent, modifier = Modifier.size(16.dp))
                Spacer(Modifier.size(8.dp))
                Text("Calculation history", color = p.surface.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.size(8.dp))
                Text("${history.size}", fontSize = 10.sp, fontWeight = FontWeight.SemiBold,
                    color = p.accentTextOnTint,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(p.tint(p.accent))
                        .border(1.dp, p.tintBorder(p.accent), RoundedCornerShape(50))
                        .padding(horizontal = 8.dp, vertical = 3.dp))
                Spacer(modifier = Modifier.weight(1f))
                if (history.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(Color(0xFFFF6B6B).copy(alpha = p.tintAlpha))
                            .border(1.dp, Color(0xFFFF6B6B).copy(alpha = p.borderTintAlpha), RoundedCornerShape(50))
                            .clickable { vm.clearHistory() }
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Filled.Delete, contentDescription = "Clear",
                            tint = if (p.isDark) Color(0xFFFCA5A5) else Color(0xFFDC2626),
                            modifier = Modifier.size(14.dp))
                        Spacer(Modifier.size(6.dp))
                        Text("Clear all", color = if (p.isDark) Color(0xFFFCA5A5) else Color(0xFFDC2626), fontSize = 12.sp)
                    }
                }
            }
            Spacer(Modifier.height(16.dp))

            if (history.isEmpty()) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(Icons.Filled.History, contentDescription = null, tint = p.surface.textDim, modifier = Modifier.size(36.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("No calculations yet — start computing to build history.",
                        color = p.surface.textMeta, fontSize = 12.sp, textAlign = TextAlign.Center)
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxWidth().height(560.dp)) {
                    items(history) { entry -> HistoryRow(entry) }
                }
            }
        }
    }
}

@Composable
private fun HistoryRow(entry: HistoryEntry) {
    val p = LocalAppPalette.current

    data class Badge(val color: Color, val labelDark: Color, val labelLight: Color, val text: String)
    val b = when (entry.mode) {
        "std"  -> Badge(p.theme.modeStandard,   Color.White,        p.theme.primaryText, "STANDARD")
        "prog" -> Badge(p.theme.modeProgrammer, Color(0xFFFBBF24),  Color(0xFF92400E),   "PROGRAMMER")
        "unit" -> Badge(p.theme.modeUnits,      Color(0xFF86EFAC), Color(0xFF166534),   "UNIT")
        "ccy"  -> Badge(p.theme.modeCurrency,   Color(0xFFFCA5A5), Color(0xFFDC2626),   "CURRENCY")
        else   -> Badge(p.theme.modeScientific, Color(0xFF5EEAD4), Color(0xFF115E59),   "SCI")
    }
    val labelColor = if (p.isDark) b.labelDark else b.labelLight

    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(b.text, color = labelColor, fontSize = 9.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(b.color.copy(alpha = p.tintAlpha))
                .border(1.dp, b.color.copy(alpha = p.borderTintAlpha), RoundedCornerShape(50))
                .padding(horizontal = 8.dp, vertical = 3.dp))
        Spacer(Modifier.size(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(entry.expression, color = p.surface.textMuted, fontSize = 11.sp,
                fontFamily = FontFamily.Monospace, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("= ${entry.result}", color = p.surface.text, fontSize = 13.sp,
                fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(entry.timestamp)),
            color = p.surface.textMeta, fontSize = 10.sp)
    }
    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(p.surface.border))
}
