-dontwarn kotlinx.serialization.**
-keepattributes *Annotation*, InnerClasses
-keep,allowobfuscation,allowshrinking class kotlin.Metadata

# Retrofit
-keepattributes Signature, Exceptions
-keepclassmembers,allowshrinking,allowobfuscation interface * {
    @retrofit2.http.* <methods>;
}

# kotlinx-serialization
-keep,includedescriptorclasses class com.moderncalc.app.**$$serializer { *; }
-keepclassmembers class com.moderncalc.app.** { *** Companion; }
-keepclasseswithmembers class com.moderncalc.app.** { kotlinx.serialization.KSerializer serializer(...); }
