# Gradle wrapper note

The Gradle wrapper JAR (`gradle-wrapper.jar`) is a binary file that Android Studio
will automatically download for you on first sync.

**You do NOT need to manually add it.** When you open this project:
1. Open in Android Studio → File → Open → select this project folder
2. Android Studio detects the missing wrapper JAR and downloads it based on
   `gradle-wrapper.properties` (Gradle 8.9)
3. Sync completes and the project is ready to build
