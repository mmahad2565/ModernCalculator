# Modern Calculator — Android

A complete, production-ready Android calculator built with **Kotlin + Jetpack Compose + Material 3**.

## Features
- **Standard** — full arithmetic, %, ±, parentheses, memory (MC / MR / M+ / M−)
- **Scientific** — sin / cos / tan (+ inverse), sinh, log, ln, √, ∛, x², xʸ, eˣ, |x|, factorial, π, e, DEG/RAD toggle
- **Programmer** — live HEX / DEC / OCT / BIN conversion, bitwise AND / OR / XOR / NOT, << / >>
- **Unit converter** — Length, Weight, Volume, Area, Speed, Time, Temperature
- **Currency** — live rates from `open.er-api.com`
- **History** — persisted with Room DB
- **Dark mode** + **5 color themes** — Lilac, Ocean, Sunset, Forest, Midnight (saved with DataStore)
- Safe expression evaluator — tokenizer + shunting-yard, no `eval()`

## How to build

1. **Install Android Studio** (Hedgehog | 2023.1.1 or newer): https://developer.android.com/studio
2. Open the `ModernCalculator` folder: **File → Open** → select this folder.
3. Wait for Gradle sync to finish (first sync downloads dependencies — a few minutes).
4. Click the green ▶ **Run** button.
   - Choose an emulator (create one via **Device Manager**) or plug in a physical device with USB debugging enabled.
5. To build a release APK: **Build → Build Bundle(s)/APK(s) → Build APK(s)**. The APK lands in `app/build/outputs/apk/`.

## Requirements
- Android Studio Hedgehog+ (Iguana / Jellyfish also fine)
- JDK 17 (bundled with Android Studio)
- Android SDK 34 (installed automatically on first sync)
- Minimum device: Android 7.0 (API 24)
